package ir.fajr.alarm;

/** Fajr time calculation (praytimes.org algorithm), Tehran Geophysics method: Fajr angle 17.7° */
public final class FajrCalc {
    public static final double FAJR_ANGLE = 17.7;

    /** Returns Fajr as hours (local clock) for the given date. tz = UTC offset in hours. */
    public static double fajrHours(int y, int m, int d, double lat, double lng, double tz) {
        double jd = julian(y, m, d) - lng / (15.0 * 24.0);
        double fajr = 5.0;
        for (int i = 0; i < 3; i++) {
            double[] sp = sunPosition(jd + fajr / 24.0);
            double decl = sp[0], eqt = sp[1];
            double noon = fixHour(12 - eqt);
            double cos = (-Math.sin(rad(FAJR_ANGLE)) - Math.sin(rad(decl)) * Math.sin(rad(lat)))
                    / (Math.cos(rad(decl)) * Math.cos(rad(lat)));
            cos = Math.max(-1, Math.min(1, cos));
            double t = Math.toDegrees(Math.acos(cos)) / 15.0;
            fajr = noon - t;
        }
        return fajr + tz - lng / 15.0;
    }

    private static double[] sunPosition(double jd) {
        double D = jd - 2451545.0;
        double g = fixAngle(357.529 + 0.98560028 * D);
        double q = fixAngle(280.459 + 0.98564736 * D);
        double L = fixAngle(q + 1.915 * Math.sin(rad(g)) + 0.020 * Math.sin(rad(2 * g)));
        double e = 23.439 - 0.00000036 * D;
        double ra = Math.toDegrees(Math.atan2(Math.cos(rad(e)) * Math.sin(rad(L)), Math.cos(rad(L)))) / 15.0;
        double eqt = q / 15.0 - fixHour(ra);
        double decl = Math.toDegrees(Math.asin(Math.sin(rad(e)) * Math.sin(rad(L))));
        return new double[]{decl, eqt};
    }

    private static double julian(int y, int m, int d) {
        if (m <= 2) { y -= 1; m += 12; }
        double A = Math.floor(y / 100.0);
        double B = 2 - A + Math.floor(A / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
    }

    private static double rad(double d) { return d * Math.PI / 180.0; }
    private static double fixAngle(double a) { a = a - 360.0 * Math.floor(a / 360.0); return a < 0 ? a + 360 : a; }
    private static double fixHour(double a) { a = a - 24.0 * Math.floor(a / 24.0); return a < 0 ? a + 24 : a; }
}
