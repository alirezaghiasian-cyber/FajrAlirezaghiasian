package ir.fajr.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.util.TimeZone;

public final class Scheduler {
    public static final String PREFS = "fajr";

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Fajr time (epoch millis) for the day of the given calendar. */
    public static long fajrMillis(Context c, Calendar day) {
        SharedPreferences p = prefs(c);
        double lat = Double.parseDouble(p.getString("lat", "35.6892"));
        double lng = Double.parseDouble(p.getString("lng", "51.3890"));
        Calendar cal = (Calendar) day.clone();
        cal.set(Calendar.HOUR_OF_DAY, 12);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        double tz = TimeZone.getDefault().getOffset(cal.getTimeInMillis()) / 3600000.0;
        double h = FajrCalc.fajrHours(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH), lat, lng, tz);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        return cal.getTimeInMillis() + Math.round(h * 3600000.0);
    }

    /** Next wake-up time: Fajr minus offset, today or tomorrow. */
    public static long nextAlarm(Context c) {
        int offset = prefs(c).getInt("offset", 10);
        long now = System.currentTimeMillis();
        Calendar day = Calendar.getInstance();
        for (int i = 0; i < 3; i++) {
            long t = fajrMillis(c, day) - offset * 60000L;
            if (t > now + 30000) return t;
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        return now + 86400000L;
    }

    public static long schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent fire = PendingIntent.getActivity(c, 1,
                new Intent(c, AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (!prefs(c).getBoolean("enabled", true)) {
            am.cancel(fire);
            return -1;
        }
        PendingIntent show = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long t = nextAlarm(c);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, show), fire);
        return t;
    }
}
