package ir.fajr.alarm;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText lat, lng, offset;
    private CheckBox enabled;
    private TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences p = Scheduler.prefs(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 64, 48, 48);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("بیدارباش قبل از اذان صبح");
        title.setTextSize(24);
        root.addView(title);

        lat = field(root, "عرض جغرافیایی (پیش‌فرض: تهران)", p.getString("lat", "35.6892"), true);
        lng = field(root, "طول جغرافیایی", p.getString("lng", "51.3890"), true);
        offset = field(root, "چند دقیقه قبل از اذان؟", String.valueOf(p.getInt("offset", 10)), false);

        enabled = new CheckBox(this);
        enabled.setText("آلارم روشن باشد");
        enabled.setChecked(p.getBoolean("enabled", true));
        root.addView(enabled);

        Button save = new Button(this);
        save.setText("ذخیره و تنظیم آلارم");
        root.addView(save);
        save.setOnClickListener(v -> save());

        Button test = new Button(this);
        test.setText("تست آلارم (همین حالا)");
        root.addView(test);
        test.setOnClickListener(v -> startActivity(new android.content.Intent(this, AlarmActivity.class)));

        status = new TextView(this);
        status.setTextSize(18);
        status.setPadding(0, 40, 0, 0);
        root.addView(status);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
        refresh(Scheduler.schedule(this));
    }

    private EditText field(LinearLayout root, String label, String value, boolean decimal) {
        TextView l = new TextView(this);
        l.setText(label);
        l.setPadding(0, 32, 0, 0);
        root.addView(l);
        EditText e = new EditText(this);
        e.setText(value);
        e.setInputType(decimal
                ? InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED
                : InputType.TYPE_CLASS_NUMBER);
        root.addView(e);
        return e;
    }

    private void save() {
        try {
            double la = Double.parseDouble(lat.getText().toString().trim());
            double lo = Double.parseDouble(lng.getText().toString().trim());
            int off = Integer.parseInt(offset.getText().toString().trim());
            if (Math.abs(la) > 66 || Math.abs(lo) > 180 || off < 0 || off > 120) throw new IllegalArgumentException();
            Scheduler.prefs(this).edit()
                    .putString("lat", String.valueOf(la)).putString("lng", String.valueOf(lo))
                    .putInt("offset", off).putBoolean("enabled", enabled.isChecked()).apply();
            refresh(Scheduler.schedule(this));
            Toast.makeText(this, "ذخیره شد", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(this, "مقادیر نامعتبر است", Toast.LENGTH_LONG).show();
        }
    }

    private void refresh(long next) {
        SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.US);
        long fajrToday = Scheduler.fajrMillis(this, Calendar.getInstance());
        String s = "اذان صبح امروز: " + f.format(new Date(fajrToday));
        if (next > 0) {
            s += "\nآلارم بعدی: " + new SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.US).format(new Date(next));
        } else {
            s += "\nآلارم خاموش است";
        }
        status.setText(s);
    }
}
