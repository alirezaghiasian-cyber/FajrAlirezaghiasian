package ir.fajr.alarm;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AlarmActivity extends Activity {
    private MediaPlayer player;
    private Vibrator vibrator;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);

        Scheduler.schedule(this); // schedule tomorrow's alarm right away

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(15, 30, 60));
        root.setPadding(48, 48, 48, 48);

        int offset = Scheduler.prefs(this).getInt("offset", 10);
        TextView tv = new TextView(this);
        tv.setText("بیدار شو!\n" + offset + " دقیقه تا اذان صبح");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(30);
        tv.setGravity(Gravity.CENTER);
        root.addView(tv);

        Button stop = new Button(this);
        stop.setText("خاموش کن");
        stop.setTextSize(24);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 220);
        lp.topMargin = 80;
        root.addView(stop, lp);
        stop.setOnClickListener(v -> { stopAlarm(); finish(); });
        setContentView(root);

        startAlarm();
        handler.postDelayed(() -> { stopAlarm(); finish(); }, 5 * 60 * 1000L); // auto stop after 5 min
    }

    private void startAlarm() {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            player.setDataSource(this, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception ignored) { }
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) vibrator.vibrate(new long[]{0, 800, 800}, 0);
    }

    private void stopAlarm() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) { try { player.stop(); } catch (Exception ignored) { } player.release(); player = null; }
        if (vibrator != null) { vibrator.cancel(); vibrator = null; }
    }

    @Override protected void onDestroy() { stopAlarm(); super.onDestroy(); }
    @Override public void onBackPressed() { /* must press the stop button */ }
}
